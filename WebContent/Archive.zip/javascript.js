var value = $("input").val(); 

$(document).ready(function(){

 $("#message").hide();
});


$(document).ready(function(){
	  $("input").keyup(function(){
	    $("#message").text(this.value + ", yur a fegit");
	  });
	});



$(document).ready(function(){
	 
		 
		 $('#message').addClass('animated rotateIn');

	 
	});



$(document).ready(function(){
	  $("#button").click(function(){
	    $("#message").fadeIn();
	  });
	  
	
	});

$(document).ready(function(){
	  $("input").keyup(function(){
	    $("#message").hide();
	  });
	});

